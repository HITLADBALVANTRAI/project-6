side = #Take the user input for side value

peri_sq = 4 * side
area_sq = side ** 2
area_cube = 6 * (side ** 2)
vol_cube = side ** 3

print("\nThe perimeter of square is : ", peri_sq, 
      "\nThe area of square is : ", #write the variable name for corresponding, 
      "\nThe area of cube is : ", #write the variable name for corresponding,
     "\nThe volume of cube is : ", #write the variable name for corresponding)

radius = #Take the user input for radius value

peri_cir = 2 *(22/7) * radius
area_cir = (22/7) * (radius) ** 2
area_sph = 4 * (22/7) * (radius) ** 2
vol_sph = (4/3) * (22/7) * (radius) ** 3

print("\nThe perimeter of circle is : ", #write the variable name for corresponding, 
      "\nThe area of circle is : ", #write the variable name for corresponding, 
      "\nThe area of sphere is : ", #write the variable name for corresponding,
     "\nThe volume of sphere is : ", #write the variable name for corresponding)

area_cone = (22/7) * side * radius

print("\nThe area of cone is : ",#write the variable name for corresponding)
